import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { PRESETS } from './examples.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const read = (name) => readFile(join(root, name), 'utf8');
const [html, css, core, presets, app] = await Promise.all([
  read('index.html'), read('styles.css'), read('interpreter.mjs'), read('examples.mjs'), read('app.mjs'),
]);

function inlineModule(source) {
  return source.replace(/^import .+;\n/gm, '').replace(/^export (const|class|function) /gm, '$1 ');
}

const script = [core, presets, app].map(inlineModule).join('\n\n').replace(/<\/script/gi, '<\\/script');
const standalone = html
  .replace('<html lang="ru">', '<html lang="ru" data-standalone="true">')
  .replace('<link rel="stylesheet" href="styles.css">', `<style>\n${css}\n</style>`)
  .replace('<script type="module" src="app.mjs"></script>', `<script type="module">\n${script}\n</script>`);

await writeFile(join(root, 'Fucking-C.html'), standalone);
await mkdir(join(root, 'examples'), { recursive: true });
for (const [key, preset] of Object.entries(PRESETS)) {
  if (key !== 'empty') await writeFile(join(root, 'examples', preset.filename), preset.source + '\n');
}
console.log('Готово: автономный Fucking-C.html и 4 примера .fc. Внешних зависимостей нет.');
