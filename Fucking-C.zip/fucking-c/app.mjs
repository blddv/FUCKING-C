import { COMMANDS, compile, VirtualMachine, encodeText, MAX_SOURCE_LENGTH } from './interpreter.mjs';
import { PRESETS } from './examples.mjs';

const $ = (id) => document.getElementById(id);
const editor = $('code');
const inputField = $('program-input');
const encoder = new TextEncoder();
const decoder = new TextDecoder();
const STORAGE_KEY = 'fucking-c.playground.v1';
const PREVIEW_BYTES = 4096;
let machine = null;
let state = 'idle';
let outputMode = 'text';
let frame = 0;
let elapsed = 0;
let filename = 'hello.fc';
let lineCount = 1;
let caretLine = 1;
let toastTimeout = 0;
let saveTimeout = 0;

function setStatus(label, kind = '') {
  $('status').textContent = label;
  $('status-dot').className = `status-dot ${kind}`;
}

function setControls() {
  const running = state === 'running';
  editor.readOnly = running;
  inputField.disabled = running;
  $('example').disabled = running;
  $('open-generator').disabled = running;
  $('step').disabled = running;
  document.querySelectorAll('[data-insert]').forEach((button) => { button.disabled = running; });
  $('run-label').textContent = running ? 'Пауза' : state === 'paused' ? 'Продолжить' : 'Запустить';
  $('run-icon').setAttribute('href', running ? '#i-pause' : '#i-play');
  $('run').setAttribute('aria-label', running ? 'Приостановить выполнение' : 'Запустить программу');
}

function renderGutter() {
  const rowHeight = 27;
  const first = Math.floor(editor.scrollTop / rowHeight);
  const visible = Math.ceil((editor.clientHeight || 302) / rowHeight) + 2;
  const current = machine?.currentToken?.line ?? caretLine;
  const rows = document.createDocumentFragment();
  for (let i = first + 1; i <= Math.min(lineCount, first + visible); i += 1) {
    const row = document.createElement('div');
    row.textContent = i;
    if (i === current) row.className = 'current-line';
    rows.append(row);
  }
  $('gutter').replaceChildren(rows);
  $('gutter').style.paddingTop = '21px';
  $('gutter').style.transform = `translateY(-${editor.scrollTop % rowHeight}px)`;
  $('gutter').style.height = `${editor.clientHeight + rowHeight}px`;
}

function updateCaret() {
  const preceding = editor.value.slice(0, editor.selectionStart);
  const lines = preceding.split(/\r\n|[\r\n]/u);
  caretLine = lines.length;
  $('caret-position').textContent = `Стр ${caretLine} : ${[...lines.at(-1)].length + 1}`;
  renderGutter();
}

function updateEditorMeta() {
  lineCount = editor.value.split(/\r\n|[\r\n]/u).length;
  try {
    const program = compile(editor.value);
    $('token-count').textContent = `${program.tokens.length.toLocaleString('ru-RU')} команд`;
    $('token-count').title = 'Код синтаксически корректен';
  } catch (error) {
    $('token-count').textContent = 'Ошибка синтаксиса';
    $('token-count').title = error.message;
  }
  $('filename').textContent = filename;
  updateCaret();
}

function renderMemory() {
  const count = window.innerWidth <= 580 ? 8 : 16;
  const pointer = machine?.pointer ?? 0;
  const start = Math.floor(pointer / count) * count;
  const cells = document.createDocumentFragment();
  for (let i = start; i < start + count; i += 1) {
    const value = machine?.memory[i] ?? 0;
    const cell = document.createElement('div');
    cell.className = `memory-cell${i === pointer ? ' current' : ''}${value ? ' changed' : ''}`;
    cell.setAttribute('aria-label', `Ячейка ${i}: ${value}${i === pointer ? ', текущая' : ''}`);
    const address = document.createElement('span');
    address.className = 'memory-address';
    address.textContent = String(i).padStart(5, '0');
    const content = document.createElement('span');
    content.className = 'memory-value';
    content.textContent = String(value).padStart(3, '0');
    cell.append(address, content);
    cells.append(cell);
  }
  $('memory').replaceChildren(cells);
  $('pointer-label').querySelector('b').textContent = String(pointer).padStart(5, '0');
  $('next-token').textContent = `Следующая команда: ${machine?.currentToken?.token ?? '—'}`;
}

function renderOutput() {
  const bytes = machine?.output ?? [];
  const preview = Uint8Array.from(bytes.slice(0, PREVIEW_BYTES));
  if (outputMode === 'hex') {
    const lines = [];
    for (let i = 0; i < preview.length; i += 16) {
      lines.push([...preview.slice(i, i + 16)].map((byte) => byte.toString(16).padStart(2, '0').toUpperCase()).join(' '));
    }
    $('output').textContent = lines.join('\n');
  } else {
    $('output').textContent = decoder.decode(preview);
  }
  $('output').classList.toggle('hex-output', outputMode === 'hex');
  $('output').hidden = bytes.length === 0;
  $('output-placeholder').hidden = bytes.length > 0;
  $('output-truncated').hidden = bytes.length <= PREVIEW_BYTES;
  $('output-truncated').textContent = `Показаны первые ${PREVIEW_BYTES.toLocaleString('ru-RU')} из ${bytes.length.toLocaleString('ru-RU')} байт. Копирование сохраняет весь текст.`;
  $('step-count').textContent = (machine?.steps ?? 0).toLocaleString('ru-RU');
  $('output-count').textContent = bytes.length.toLocaleString('ru-RU');
  $('elapsed').textContent = machine ? `${elapsed.toFixed(1)} мс` : '— мс';
}

function renderMachine() {
  renderMemory();
  renderOutput();
  renderGutter();
  setControls();
}

function revealToken(token, focus = false) {
  if (!token || token.start === null) return;
  editor.setSelectionRange(token.start, token.end);
  const top = (token.line - 1) * 27;
  if (top < editor.scrollTop || top > editor.scrollTop + editor.clientHeight - 60) {
    editor.scrollTop = Math.max(0, top - editor.clientHeight / 3);
  }
  if (focus) editor.focus({ preventScroll: true });
  updateCaret();
}

function showError(error) {
  state = 'error';
  $('diagnostic').textContent = error.message;
  $('diagnostic').hidden = false;
  setStatus(error.code === 'STEP_LIMIT' ? 'Лимит шагов' : 'Ошибка', 'error');
  setControls();
  if (error.start !== undefined && error.start !== null) revealToken(error, true);
}

function resetExecution() {
  cancelAnimationFrame(frame);
  frame = 0;
  machine = null;
  state = 'idle';
  elapsed = 0;
  $('diagnostic').hidden = true;
  setStatus('Готов к запуску');
  renderMachine();
}

function prepareMachine() {
  resetExecution();
  try {
    machine = new VirtualMachine(compile(editor.value), { input: encoder.encode(inputField.value) });
    state = machine.halted ? 'done' : 'paused';
    return true;
  } catch (error) {
    showError(error);
    return false;
  }
}

function finish() {
  state = 'done';
  setStatus(machine.output.length ? 'Выполнено' : 'Выполнено · без вывода', 'done');
  renderMachine();
}

function tick() {
  frame = 0;
  if (state !== 'running') return;
  const started = performance.now();
  let failure = null;
  try {
    for (let i = 0; i < 10_000 && !machine.halted; i += 1) machine.step();
  } catch (error) {
    failure = error;
  }
  elapsed += performance.now() - started;
  renderMachine();
  if (failure) {
    showError(failure);
    return;
  }
  if (machine.halted) {
    finish();
    return;
  }
  frame = requestAnimationFrame(tick);
}

function toggleRun() {
  if (state === 'running') {
    cancelAnimationFrame(frame);
    frame = 0;
    state = 'paused';
    setStatus('Пауза');
    renderMachine();
    revealToken(machine.currentToken);
    return;
  }
  if (!machine || machine.halted || machine.error) {
    if (!prepareMachine()) return;
  }
  if (machine.halted) {
    finish();
    return;
  }
  state = 'running';
  $('diagnostic').hidden = true;
  setStatus('Выполняется', 'running');
  setControls();
  frame = requestAnimationFrame(tick);
}

function stepOnce() {
  if (state === 'running') return;
  if (!machine || machine.halted || machine.error) {
    if (!prepareMachine()) return;
  }
  if (machine.halted) {
    finish();
    return;
  }
  const started = performance.now();
  let failure = null;
  try {
    machine.step();
  } catch (error) {
    failure = error;
  }
  elapsed += performance.now() - started;
  if (failure) {
    showError(failure);
    renderMachine();
  } else if (machine.halted) finish();
  else {
    state = 'paused';
    setStatus('Пошаговый режим');
    renderMachine();
    revealToken(machine.currentToken);
  }
}

function persist() {
  clearTimeout(saveTimeout);
  saveTimeout = setTimeout(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ source: editor.value, input: inputField.value, preset: $('example').value, filename }));
    } catch {
      // The interpreter also works when browser storage is unavailable.
    }
  }, 200);
}

function markCustom() {
  $('example').value = 'custom';
  filename = 'program.fc';
  resetExecution();
  updateEditorMeta();
  persist();
}

function loadPreset(key) {
  const preset = PRESETS[key];
  if (!preset) return;
  editor.value = preset.source;
  inputField.value = preset.input;
  filename = preset.filename;
  $('example').value = key;
  editor.scrollTop = 0;
  resetExecution();
  updateEditorMeta();
  persist();
}

function insertToken(token) {
  if (state === 'running') return;
  const start = editor.selectionStart;
  const end = editor.selectionEnd;
  const before = start > 0 && !/\s/u.test(editor.value[start - 1]) ? ' ' : '';
  const after = end < editor.value.length && !/\s/u.test(editor.value[end]) ? ' ' : '';
  editor.setRangeText(before + token + after, start, end, 'end');
  markCustom();
  editor.focus({ preventScroll: true });
}

function toast(message) {
  clearTimeout(toastTimeout);
  $('toast').textContent = message;
  $('toast').hidden = false;
  toastTimeout = setTimeout(() => { $('toast').hidden = true; }, 2400);
}

async function copyText(text, success) {
  try {
    if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
    await navigator.clipboard.writeText(text);
    toast(success);
  } catch {
    const field = document.createElement('textarea');
    field.value = text;
    field.style.cssText = 'position:fixed;left:-10000px;top:0';
    document.body.append(field);
    field.select();
    const copied = document.execCommand('copy');
    field.remove();
    toast(copied ? success : 'Копирование недоступно. Выдели текст и нажми Ctrl+C.');
  }
}

function download(name, type, content) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function renderCommands() {
  const buttons = document.createDocumentFragment();
  const cards = document.createDocumentFragment();
  for (const command of COMMANDS) {
    const small = document.createElement('button');
    small.type = 'button';
    small.className = 'token-button';
    small.textContent = command.token;
    small.dataset.insert = command.token;
    small.title = `${command.title}: ${command.description}`;
    small.setAttribute('aria-label', `Вставить ${command.token}: ${command.title}`);
    small.addEventListener('click', () => insertToken(command.token));
    buttons.append(small);

    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'command-card';
    card.dataset.insert = command.token;
    const symbol = document.createElement('span');
    symbol.className = 'command-symbol';
    symbol.textContent = command.token;
    const title = document.createElement('h3');
    title.textContent = command.title;
    const description = document.createElement('p');
    description.textContent = command.description;
    const arrow = document.createElement('span');
    arrow.className = 'card-arrow';
    arrow.textContent = '↗';
    arrow.setAttribute('aria-hidden', 'true');
    card.append(symbol, title, description, arrow);
    card.addEventListener('click', () => {
      insertToken(command.token);
      $('playground').scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' });
    });
    cards.append(card);
  }
  $('token-buttons').replaceChildren(buttons);
  $('command-cards').replaceChildren(cards);
}

function updateGeneratorCount() {
  const count = encoder.encode($('generator-text').value).length;
  $('generator-count').textContent = `${count} / 1024 байт`;
  $('generator-error').hidden = count <= 1024;
  $('generator-error').textContent = 'Слишком длинный текст: максимум 1024 байта UTF-8.';
}

$('run').addEventListener('click', toggleRun);
$('step').addEventListener('click', stepOnce);
$('reset').addEventListener('click', resetExecution);
$('example').addEventListener('change', (event) => loadPreset(event.target.value));
editor.addEventListener('input', markCustom);
editor.addEventListener('scroll', renderGutter);
editor.addEventListener('click', updateCaret);
editor.addEventListener('keyup', updateCaret);
editor.addEventListener('select', updateCaret);
editor.addEventListener('keydown', (event) => {
  if (event.key === 'Tab' && !editor.readOnly && !event.shiftKey) {
    event.preventDefault();
    editor.setRangeText('\t', editor.selectionStart, editor.selectionEnd, 'end');
    markCustom();
  }
});
inputField.addEventListener('input', () => { resetExecution(); persist(); });
window.addEventListener('resize', () => { renderMemory(); renderGutter(); });
document.addEventListener('keydown', (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key === 'Enter' && !$('generator-dialog').open) {
    event.preventDefault();
    toggleRun();
  }
});
$('text-mode').addEventListener('click', () => {
  outputMode = 'text';
  $('text-mode').classList.add('active');
  $('hex-mode').classList.remove('active');
  $('text-mode').setAttribute('aria-pressed', 'true');
  $('hex-mode').setAttribute('aria-pressed', 'false');
  renderOutput();
});
$('hex-mode').addEventListener('click', () => {
  outputMode = 'hex';
  $('hex-mode').classList.add('active');
  $('text-mode').classList.remove('active');
  $('hex-mode').setAttribute('aria-pressed', 'true');
  $('text-mode').setAttribute('aria-pressed', 'false');
  renderOutput();
});
$('copy-code').addEventListener('click', () => copyText(editor.value, 'Код скопирован'));
$('copy-output').addEventListener('click', () => {
  if (!machine?.output.length) { toast('Вывод пока пуст'); return; }
  const text = outputMode === 'hex'
    ? machine.output.map((byte) => byte.toString(16).padStart(2, '0').toUpperCase()).join(' ')
    : decoder.decode(machine.getOutputBytes());
  copyText(text, 'Вывод скопирован');
});
$('download-code').addEventListener('click', () => download(filename, 'text/plain;charset=utf-8', editor.value));
$('download-app').addEventListener('click', () => {
  if (document.documentElement.dataset.standalone === 'true') {
    download('Fucking-C.html', 'text/html;charset=utf-8', '<!doctype html>\n' + document.documentElement.outerHTML);
  } else {
    const link = document.createElement('a');
    link.href = 'Fucking-C.html';
    link.download = 'Fucking-C.html';
    document.body.append(link);
    link.click();
    link.remove();
  }
});
$('open-generator').addEventListener('click', () => {
  updateGeneratorCount();
  $('generator-dialog').showModal();
  $('generator-text').focus();
});
$('close-generator').addEventListener('click', () => $('generator-dialog').close());
$('generator-dialog').addEventListener('click', (event) => {
  const rect = $('generator-dialog').getBoundingClientRect();
  if (event.target === $('generator-dialog') && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) $('generator-dialog').close();
});
$('generator-text').addEventListener('input', updateGeneratorCount);
$('generator-form').addEventListener('submit', (event) => {
  event.preventDefault();
  try {
    const source = encodeText($('generator-text').value);
    editor.value = source;
    inputField.value = '';
    editor.scrollTop = 0;
    markCustom();
    filename = 'generated.fc';
    updateEditorMeta();
    persist();
    $('generator-dialog').close();
    toast('Программа готова. Осталось запустить.');
  } catch (error) {
    $('generator-error').textContent = error.message;
    $('generator-error').hidden = false;
  }
});

renderCommands();
let restored = false;
try {
  const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? 'null');
  if (saved && typeof saved.source === 'string' && saved.source.length <= MAX_SOURCE_LENGTH && typeof saved.input === 'string' && saved.input.length <= 65536) {
    editor.value = saved.source;
    inputField.value = saved.input;
    $('example').value = saved.preset in PRESETS ? saved.preset : 'custom';
    filename = /^[a-z0-9-]+\.fc$/.test(saved.filename) ? saved.filename : 'program.fc';
    restored = true;
  }
} catch {
  // Storage can be denied for local files or private browsing.
}
if (!restored) loadPreset('hello');
else { resetExecution(); updateEditorMeta(); }
updateGeneratorCount();
