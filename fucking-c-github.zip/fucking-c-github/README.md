# Fucking C

**One letter. Real functions. Native C++.**

[Русский](README.ru.md) · [Language reference](docs/language.md) · [Contributing](CONTRIBUTING.md) · [Publishing](PUBLISH.md)

Fucking C is a high-level esoteric programming language whose source tokens are all variations of **C**. The interpreter, lexer, Pratt parser, runtime, REPL, and test suite are implemented in **C++20**.

It has variables, recursive functions, closures, Unicode strings, mutable lists, and control flow. It is not a C compiler, a Brainfuck tape, a website, or a wrapper around Python.

**Version:** 2.1.0 · **Project license:** [The Unlicense](LICENSE), a public-domain dedication.

## A real program

Recursive factorial, from [`examples/factorial.fc`](examples/factorial.fc):

```text
c ƈC Ć ƈc ć Ĉ
    CC Ć ƈc C̲C ƇC ć Ĉ
        cC ƇC ċ
    ĉ
    cC ƈc C̈ ƈC Ć ƈc c̄ ƇC ć ċ
ĉ

C̶ Ć ƈC Ć ƇCCc ć ć ċ
```

This defines `factorial(n)`, then prints `factorial(6)`: **720**. `ƈC` is the function name, `ƈc` is its parameter, `ƇC` is 1, and `ƇCCc` is 6.

## Build and run

Requirements: a C++20 compiler, Make or CMake 3.20+, and **Boost 1.74+ headers**. Boost.Multiprecision is header-only; no Boost shared library or scripting runtime is needed at run time.

On Debian/Ubuntu:

```sh
sudo apt install g++ make libboost-dev
make -j2
./fc examples/factorial.fc
./fc repl
```

With CMake:

```sh
sudo apt install cmake ninja-build
cmake -S . -B build/cmake -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build/cmake --parallel 2
ctest --test-dir build/cmake --output-on-failure
build/cmake/fc examples/map.fc
```

Or compile directly:

```sh
g++ -std=c++20 -O2 -Iinclude \
    src/syntax.cpp src/runtime.cpp src/cli.cpp src/main.cpp -o fc
```

Linux is the verified platform. macOS and Windows builds are not yet verified; a compiler's C++20 standard library must include floating-point `from_chars` and `to_chars`. Source control intentionally contains no executables or build products.

## Features

- Integers up to 4096 bits, finite binary64 floats, booleans, and null.
- Unicode strings and mutable, heterogeneous, possibly cyclic lists.
- Variables, assignment, nested scopes, and lexical environment capture.
- Arithmetic precedence, chained comparisons, and short-circuit logic.
- `if/else`, `while`, `for/in`, `break`, and `continue`.
- Named and anonymous functions, recursion, higher-order functions, and closures.
- Negative indexing, `append`, `pop`, `range`, conversions, and assertions.
- Line-oriented input, output, a persistent REPL, and source diagnostics.
- A tracing collector for runtime objects between completed commands.

This is an experimental language implementation, not a production compiler or a security sandbox. There are no modules, classes, FFI, file-system builtins, or user-defined exception handlers yet.

## The C-only alphabet

**Separate every token with whitespace**, including punctuation. Source files are UTF-8; newlines do not replace the statement terminator. There are no comments in `.fc` files.

| Tokens | Meaning |
|---|---|
| `C` / `c` | variable declaration / function |
| `CC` / `cc` | if / else |
| `Cc` | while |
| `CCC` / `CCc` | for / in |
| `cC` | return |
| `CcC` / `Ccc` | break / continue |
| `Ć` / `ć` | parentheses |
| `Ĉ` / `ĉ` | block delimiters |
| `Č` / `č` | list/index delimiters |
| `Ċ` / `ċ` | comma / statement terminator |
| `Ç` | assignment |
| `C̶` / `c̶` | print / input |

Names start with `ƈ`, followed by `c/C`. Integer literals start with `Ƈ`, followed by binary digits where `c=0` and `C=1`. String literals start with `Ȼ`, followed by UTF-8 bytes encoded with those same bits.

```sh
./fc literal int 42
# ƇCcCcCc

./fc literal float 2.5
# Ć ƇCcC c̈ ƇCc ć

./fc literal str 'Привет, C!'
./fc literal name counter
```

The restriction applies to **source spelling**, not to input, output, or string values. All operators, Unicode spellings, grammar rules, and builtin functions are documented in the [language reference](docs/language.md).

## Command line

```sh
./fc run examples/factorial.fc --stats
./fc check examples/factorial.fc
./fc tokens examples/factorial.fc
./fc syntax
./fc examples/echo.fc --input 'Hello, C!'
./fc repl
```

`run` can be omitted. Runtime options are `--input TEXT`, `--max-steps N`, `--max-depth N`, `--max-output N`, and `--stats`. Program data goes to stdout; diagnostics and statistics go to stderr. Exit codes: `0` success, `2` syntax/argument errors, `1` runtime/resource/file errors.

The REPL supports multiline blocks, `.help`, `.quit`, and `.exit`. Standalone expressions may omit the final `ċ` and print their result.

## Examples

| Program | Demonstrates | Output |
|---|---|---|
| [hello.fc](examples/hello.fc) | Unicode string output | `Привет, C!` |
| [factorial.fc](examples/factorial.fc) | Recursive function | `720` |
| [fibonacci.fc](examples/fibonacci.fc) | Variables and while | `6765` |
| [map.fc](examples/map.fc) | Higher-order functions and lists | `[1, 4, 9, 16]` |
| [closure.fc](examples/closure.fc) | Mutable captured state | `1 2 3` |
| [lists.fc](examples/lists.fc) | Indexing and list builtins | Several lines |
| [loops.fc](examples/loops.fc) | Range, break, continue | `31` |
| [echo.fc](examples/echo.fc) | Input until EOF | Echoes input lines |

## Tests and packaging

```sh
make test
make sanitize
```

The C++ suite covers syntax, types, Unicode, arithmetic, functions, scopes, closures, cycles, limits, CLI behavior, and the REPL. It includes 200 deterministic arithmetic trees checked against independently calculated results.

The [CI workflow](.github/workflows/ci.yml) is configured to build and test with GCC and Clang on Linux and to run ASan/UBSan separately. The [package workflow](.github/workflows/package.yml) is manual and only uploads a build artifact: it does **not** create a public GitHub Release.

Create a native archive locally:

```sh
cmake -S . -B build/release -DCMAKE_BUILD_TYPE=Release
cmake --build build/release --parallel 2
ctest --test-dir build/release --output-on-failure
cmake --build build/release --target package
```

Archives appear in `build/release/packages/` and contain `bin/fc`, examples, documentation, and both project and third-party license notices. Native Linux binaries require compatible system C/C++ libraries. See [release instructions](docs/releasing.md) before publishing one.

## License

Original project source, tests, documentation, and examples are released under **[The Unlicense](LICENSE)**, expressing a public-domain dedication and permission for unrestricted use.

Third-party software is **not** reclassified as public domain. Boost remains under the [Boost Software License 1.0](LICENSES/BSL-1.0.txt); see [THIRD_PARTY.md](THIRD_PARTY.md).
