# Fucking C

**Одна буква. Настоящие функции. Нативный C++.**

[English](README.md) · [Семантика](docs/language.ru.md) · [Полная таблица токенов](docs/language.md) · [Публикация на GitHub](PUBLISH.md)

Fucking C — высокоуровневый эзотерический язык, в котором все токены исходника состоят из вариаций **C**. Лексер, Pratt-парсер, интерпретатор, REPL и тесты написаны на **C++20**. Это не компилятор обычного C, не Brainfuck, не сайт и не обёртка над Python.

Версия: **2.1.0**. Лицензия собственного кода: **[The Unlicense](LICENSE)** — посвящение в Public Domain.

## Факториал

```text
c ƈC Ć ƈc ć Ĉ
    CC Ć ƈc C̲C ƇC ć Ĉ
        cC ƇC ċ
    ĉ
    cC ƈc C̈ ƈC Ć ƈc c̄ ƇC ć ċ
ĉ

C̶ Ć ƈC Ć ƇCCc ć ć ċ
```

Программа объявляет `factorial(n)` и выводит `factorial(6)`: **720**. `ƈC` — имя функции, `ƈc` — параметр, `ƇC` — 1, `ƇCCc` — 6.

## Сборка

Нужны C++20-компилятор, Make или CMake 3.20+, заголовки Boost 1.74+. Boost.Multiprecision — header-only: отдельная библиотека Boost и скриптовый runtime для запуска не нужны.

Debian/Ubuntu:

```sh
sudo apt install g++ make libboost-dev
make -j2
./fc examples/factorial.fc
./fc repl
```

Через CMake:

```sh
sudo apt install cmake ninja-build
cmake -S . -B build/cmake -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build/cmake --parallel 2
ctest --test-dir build/cmake --output-on-failure
build/cmake/fc examples/map.fc
```

Проверенная платформа — Linux. Сборки macOS/Windows пока не проверены; стандартная библиотека компилятора должна поддерживать floating-point `from_chars` и `to_chars`. Бинарники и папки сборки намеренно не включаются в Git.

## Возможности

- `int` до 4096 бит, конечный `float`, `bool`, `null`.
- Unicode-строки, изменяемые списки, функции как значения.
- Переменные, присваивания, вложенные области видимости.
- Арифметика с приоритетами, сравнения, логическое короткое замыкание.
- `if/else`, `while`, `for/in`, `break/continue`.
- Именованные и анонимные функции, рекурсия, `return`, замыкания.
- Индексы, включая отрицательные, `append`, `pop`, `range`.
- Консольный ввод/вывод, REPL, диагностика и цепочка вызовов.
- Сборка мусора между командами, в том числе для циклических списков.

Это экспериментальный язык, не промышленный компилятор и не безопасная песочница. Модулей, классов, FFI, файлового API и пользовательского `catch` пока нет.

## Как писать

**Каждый токен отделяется пробелами**, табами или переносами строк. Скобки и операторы — тоже отдельные токены. Исходники UTF-8, комментариев в `.fc` нет.

| Токены | Смысл |
|---|---|
| `C` / `c` | переменная / функция |
| `CC` / `cc` | if / else |
| `Cc` | while |
| `CCC` / `CCc` | for / in |
| `cC` | return |
| `CcC` / `Ccc` | break / continue |
| `Ć` / `ć` | круглые скобки |
| `Ĉ` / `ĉ` | блок |
| `Č` / `č` | список или индекс |
| `Ċ` / `ċ` | запятая / конец инструкции |
| `Ç` | присваивание |
| `C̶` / `c̶` | print / input |

Имя начинается с `ƈ` и продолжается `c/C`. Целое начинается с `Ƈ`, затем идут биты `c=0`, `C=1`. Строка начинается с `Ȼ`, затем идут UTF-8-байты в тех же битах.

```sh
./fc literal int 42
# ƇCcCcCc

./fc literal float 2.5
# Ć ƇCcC c̈ ƇCc ć

./fc literal str 'Привет, C!'
./fc literal name counter
```

Ограничение алфавита относится к написанию **исходника**, а не к данным. Строки, ввод и вывод могут содержать русский текст, цифры и эмодзи. Полная таблица операторов и builtins: `./fc syntax` или [справочник](docs/language.md).

## Команды терминала

```sh
./fc run examples/factorial.fc --stats
./fc check examples/factorial.fc
./fc tokens examples/factorial.fc
./fc examples/echo.fc --input 'Привет!'
./fc repl
```

Слово `run` можно опустить. Параметры: `--input TEXT`, `--max-steps N`, `--max-depth N`, `--max-output N`, `--stats`. Программа пишет данные в stdout, ошибки и статистику — в stderr. Коды завершения: `0` — успех, `2` — ошибка синтаксиса/аргументов, `1` — ошибка выполнения/ресурсов/файла.

В REPL есть `.help`, `.quit`, `.exit`, многострочные блоки и сохранение переменных. Отдельное выражение можно вводить без `ċ`: его результат будет напечатан.

## Примеры

В `examples/`: `hello.fc`, `factorial.fc`, `fibonacci.fc`, `map.fc`, `closure.fc`, `lists.fc`, `loops.fc`, `echo.fc`. Они демонстрируют Unicode, рекурсию, циклы, функции высшего порядка, замыкания и изменяемые списки.

## Проверка и пакет

```sh
make test
make sanitize
```

Тесты написаны на C++, включая 200 детерминированных случайных арифметических деревьев. GitHub Actions настроен на GCC, Clang и отдельную проверку ASan/UBSan.

```sh
cmake -S . -B build/release -DCMAKE_BUILD_TYPE=Release
cmake --build build/release --parallel 2
ctest --test-dir build/release --output-on-failure
cmake --build build/release --target package
```

Пакет появится в `build/release/packages/`: `bin/fc`, примеры, документация и лицензии. Workflow **Build release package** запускается вручную и создаёт только скачиваемый artifact — публичный GitHub Release автоматически не публикует.

## Public Domain

Собственные исходники, тесты, примеры и документация проекта опубликованы под **[The Unlicense](LICENSE)** — стандартным посвящением в Public Domain с разрешением свободного использования.

Это не меняет права на сторонние компоненты. Boost остаётся под [BSL-1.0](LICENSES/BSL-1.0.txt); подробности в [THIRD_PARTY.md](THIRD_PARTY.md).
