# Security policy

## Scope

Fucking C is an experimental native interpreter. It is **not a security sandbox** for untrusted programs. Execution, recursion, collection, and output limits help with accidental mistakes; they are not a complete denial-of-service or process-isolation boundary.

Do not expose the CLI directly as an unauthenticated remote code-execution service. If you run untrusted programs, use operating-system isolation, independent CPU/memory/time limits, and a least-privileged account.

## Supported code

Security fixes are considered for the current C++ development version on `main`. Earlier prototypes and discontinued language implementations are not maintained in this repository. There is no guaranteed response or patch SLA.

## Reporting

Use GitHub's **Report a vulnerability** option on this repository when private vulnerability reporting is enabled. Do not include credentials, private data, or sensitive exploitation details in a public issue.

If a private reporting channel is not available, open a minimal issue asking the maintainers for a private contact route, without including the sensitive details. A normal parser error, missing feature, or non-security crash can be reported using the bug template.

Useful information includes the version/commit, operating system, compiler, relevant build flags, a minimal affected program, and the observed impact. Do not test against infrastructure or users without their permission.

## Repository automation

The workflows use read-only repository permissions, disable persisted checkout credentials, and do not use `pull_request_target`. Third-party actions are pinned to full upstream commit IDs. The manual packaging workflow uploads an artifact only; it does not publish a release or push a tag.
