## Summary

Describe the change and the problem it solves. Link related issues.

## Behavior and compatibility

Explain any changes to source syntax, semantics, CLI behavior, dependencies, or platform requirements.

## Verification

List the build/test commands actually run and their results. Do not mark unrun checks as passed.

- [ ] Relevant C++ regression tests added or updated.
- [ ] `make test` or CMake/CTest passes locally.
- [ ] ASan/UBSan checked for parser/runtime/memory changes, or explained why not run.
- [ ] Documentation and changelog updated where appropriate.
- [ ] No executables, build outputs, credentials, or unrelated files included.
- [ ] I have the right to contribute this work under The Unlicense; third-party notices are preserved.
