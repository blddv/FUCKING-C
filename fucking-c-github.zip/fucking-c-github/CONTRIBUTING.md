# Contributing

Thanks for helping improve Fucking C. Keep the implementation native C++20 and keep the language's source alphabet limited to documented C variants.

## Local setup

Requirements: a C++20 compiler, Boost 1.74+ headers, and Make or CMake 3.20+.

```sh
make -j2
make test
```

For a separate CMake build:

```sh
cmake -S . -B build/dev -DCMAKE_BUILD_TYPE=Debug
cmake --build build/dev --parallel 2
ctest --test-dir build/dev --output-on-failure
```

For changes to the lexer, parser, runtime, or memory ownership, also run:

```sh
make sanitize
```

## Changes

- Open an issue before proposing a substantial language change.
- Match the existing C++ naming, layout, and restrained comment style.
- Keep source files UTF-8 with LF line endings. Do not silently replace Unicode C tokens with visually similar characters.
- Add regression tests to `tests/test_language.cpp`; include a small `.fc` example when useful.
- Preserve the CLI's stdout/stderr separation and documented exit codes.
- Update both language references when semantics change, and note user-visible changes in `CHANGELOG.md`.
- Do not commit executables, object files, `build/`, local configuration, credentials, or downloaded dependencies.
- Avoid adding runtime dependencies or network/file-system builtins without discussion.

The runtime does not use Python's evaluator, `eval`, or another scripting engine. Keep changes consistent with that design.

## Pull requests

Describe the problem, the solution, and the tests run. Include relevant issue numbers. Small, focused pull requests are easier to review than unrelated changes bundled together.

The GitHub Actions workflow is configured for GCC, Clang, and ASan/UBSan on Linux. A configured workflow is not evidence of a passing run; check the actual results on the pull request.

## Licensing and conduct

By contributing original project code or documentation, you agree to contribute it under [The Unlicense](LICENSE), the project's public-domain dedication. Only contribute work you have the right to submit. Preserve existing third-party notices; do not label someone else's licensed code as public domain.

Be respectful and constructive. Discuss the code, not personal characteristics. For sensitive security reports, follow [SECURITY.md](SECURITY.md) rather than posting details in a public issue.
