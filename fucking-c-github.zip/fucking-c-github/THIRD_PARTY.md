# Third-party software and automation

The Unlicense in the repository root applies to original Fucking C source, documentation, examples, tests, and repository configuration. It does **not** change the licensing of third-party components.

## Boost.Multiprecision

- Used type: `boost::multiprecision::cpp_int`.
- Dependency: Boost 1.74+ headers, obtained from the user's package manager.
- Runtime: no Boost shared library is linked.
- License: **Boost Software License 1.0**, reproduced in [LICENSES/BSL-1.0.txt](LICENSES/BSL-1.0.txt).
- Upstream: https://www.boost.org/doc/libs/release/libs/multiprecision/

Boost headers are not vendored. Keep the Boost notice with distributed packages that include compiled Boost code. System compiler/runtime libraries remain under their respective licenses.

## GitHub Actions

These tools are used only by GitHub's workflow runner, not by the interpreter. Their source is not bundled or relicensed by this repository.

| Action | Release | Pinned commit |
|---|---|---|
| `actions/checkout` | v7.0.1 [2](https://github.com/actions/checkout/releases) | `3d3c42e5aac5ba805825da76410c181273ba90b1` |
| `actions/upload-artifact` | v7.0.2 [3](https://github.com/actions/upload-artifact/releases/tag/v7.0.2) | `cf430e030ddbb5b0abf93d22962f4752f3646cd9` |

Release-tag commit IDs were checked against the upstream Git refs during repository preparation. Before updating an action, review its upstream release and verify the full commit ID. Workflow configuration alone does not establish that a remote GitHub run has passed.
