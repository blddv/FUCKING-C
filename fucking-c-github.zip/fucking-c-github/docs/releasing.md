# Preparing a release

This repository does not publish releases automatically. The manual **Build release package** workflow only produces a downloadable artifact.

## Before tagging

1. Review the diff and ensure the worktree is clean.
2. Check the version in `include/fucking_c.hpp`. CMake reads it from that header.
3. Move the `CHANGELOG.md` candidate notes under the version and actual publication date.
4. Run the C++ tests, sanitizer checks, and the package smoke test below.
5. Verify both [The Unlicense](../LICENSE) and [Boost's notice](../LICENSES/BSL-1.0.txt) are included.
6. Record which OS/compiler was used. A native Linux binary is not a Windows or macOS build and requires compatible system runtime libraries.

## Build locally

```sh
cmake -S . -B build/release -DCMAKE_BUILD_TYPE=Release
cmake --build build/release --parallel 2
ctest --test-dir build/release --output-on-failure
cmake --build build/release --target package
```

For Linux x86-64 and version 2.1.0, the archive is:

```text
build/release/packages/fucking-c-2.1.0-linux-x86_64.tar.gz
```

The package contains `bin/fc`, examples under `share/fucking-c/examples/`, and notices/documentation under `share/doc/fucking-c/`.

Test an extracted package from a separate temporary directory, not from the source tree:

```sh
archive="$PWD/build/release/packages/fucking-c-2.1.0-linux-x86_64.tar.gz"
check_dir="$(mktemp -d)"
tar -xzf "$archive" -C "$check_dir"
package="$check_dir/fucking-c-2.1.0-linux-x86_64"
"$package/bin/fc" "$package/share/fucking-c/examples/factorial.fc"
# 720
```

Generate checksums from inside the package directory so they contain portable relative filenames:

```sh
(cd build/release/packages && sha256sum ./*.tar.gz > SHA256SUMS)
```

The manual GitHub package workflow performs these build/test/package/checksum steps and uploads the files as an Actions artifact. It uses Ubuntu 22.04 x86-64; the resulting platform/runtime requirements follow that build environment.

## Publish deliberately

The following commands are for the maintainer to run **after reviewing and committing the release changes**. They push a tag and publish a public release; they are not part of the automatic build.

For the initial 2.1.0 release:

```sh
git tag -a v2.1.0 -m "Fucking C 2.1.0"
git push origin v2.1.0
gh release create v2.1.0 \
  build/release/packages/fucking-c-2.1.0-linux-x86_64.tar.gz \
  build/release/packages/SHA256SUMS \
  --verify-tag \
  --title "Fucking C 2.1.0" \
  --notes-file CHANGELOG.md
```

For later versions, update the version/tag/filenames consistently. Do not replace an existing tag or asset silently. Source archives are provided by GitHub for the tag; compiled build products do not belong in ordinary source commits.
