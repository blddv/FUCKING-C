# Выложить на GitHub сейчас

В этой папке уже находится корень готового исходного репозитория. Рекомендуемое имя: **`fucking-c`**. Лицензия собственного кода — **The Unlicense / Public Domain**; лицензия Boost сохранена отдельно.

Никакой репозиторий на GitHub автоматически не создаётся. Команды ниже выполняешь ты, под своим аккаунтом.

## 1. Распакуй и проверь

Открой терминал **внутри папки, где лежат README.md, LICENSE и src/**, а не уровнем выше. Не загружай ZIP как единственный файл репозитория — нужны его распакованные исходники.

```sh
make -j2
make test
```

На Debian/Ubuntu зависимости устанавливаются так:

```sh
sudo apt install g++ make libboost-dev
```

В `.gitignore` уже исключены бинарники, build-папки, объектные файлы, локальные `.env` и служебные файлы редакторов. Перед коммитом всё равно посмотри список файлов.

## 2. Первый коммит

Если распакованная папка ещё не Git-репозиторий:

```sh
git init -b main
git add .
git status --short
git diff --cached --check
git commit -m "Initial native C++ release"
```

Если Git просит имя и email автора, настрой свои значения; чужие данные в проект не подставлены. Проверь, что среди добавленных файлов нет `fc`, `fc_tests`, `build/` или старого сайта.

## 3. Создать и загрузить PUBLIC-репозиторий

Нужен [GitHub CLI](https://cli.github.com/). Если ещё не авторизован:

```sh
gh auth login
```

Следующая команда **создаст публичный репозиторий и отправит в него твой коммит**:

```sh
gh repo create fucking-c --public --source=. --remote=origin --push \
  --description "A native C++20 interpreter for a language written entirely with variations of C"
```

Для непубличной первой проверки замени `--public` на `--private`. Если репозиторий с таким именем уже существует, не перезаписывай его: выбери другое имя либо подключи нужный существующий remote вручную.

После успешной загрузки:

```sh
gh repo view --web
gh run list
```

Открой вкладку **Actions** и дождись проверки CI. Локальные тесты не заменяют первый запуск на GitHub.

## Если загружаешь через сайт

1. Создай пустой репозиторий `fucking-c`; не генерируй отдельные README, .gitignore и LICENSE — они уже есть.
2. Загрузи содержимое распакованной папки, сохранив `src/`, `include/`, `tests/`, `examples/`, `docs/`, `LICENSES/` и `.github/`.
3. Не забудь скрытые `.github`, `.gitignore`, `.gitattributes`, `.editorconfig`. Некоторые файловые диалоги их скрывают; загрузка через Git надёжнее.
4. Проверь Actions после создания коммита.

## Настройки репозитория

- Default branch: `main`.
- Description: `A native C++20 interpreter for a language written entirely with variations of C`.
- Topics: `cpp`, `cpp20`, `interpreter`, `programming-language`, `esolang`, `unicode`, `public-domain`.
- После первого успешного CI можно включить защиту `main` и обязательные проверки.
- Для приватных сообщений об уязвимостях включи private vulnerability reporting в настройках безопасности репозитория, если эта функция доступна.
- Website URL оставь пустым: у проекта нет сайта.

## Бинарники — в Release, не в Git

В исходном Git-репозитории бинарников нет. Получить пакет можно локально через CMake/CPack или вручную запустить **Actions → Build release package**.

Этот workflow только собирает artifact и контрольные суммы. Он **не публикует GitHub Release и не отправляет теги**. Дальнейшие действия — в [docs/releasing.md](docs/releasing.md).

Документация, лицензия, шаблоны и workflow готовы. Они не доказывают, что публикация уже состоялась: первые Git-коммит, push и GitHub Actions выполняются только после твоих действий.
