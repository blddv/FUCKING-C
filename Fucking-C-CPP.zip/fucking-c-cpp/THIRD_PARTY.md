# Third-party components

The C++ implementation uses the header-only `boost::multiprecision::cpp_int` integer type from Boost.Multiprecision.

- Boost website: https://www.boost.org/
- Multiprecision documentation: https://www.boost.org/doc/libs/release/libs/multiprecision/
- License: Boost Software License 1.0, reproduced in `LICENSE.boost.txt`.
- Verified build: GCC 12.2, Boost 1.74, Linux x86-64.

Boost headers are a build-time dependency. They are not vendored in this repository, and the executable does not link a Boost shared library. The supplied native executable uses the system C/C++ runtime libraries; it does not embed or launch Python, Node.js, or another language runtime.

The license text below applies to Boost, not as a separate license declaration for the new project source.
